<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
				<?php if( auth::user()->is_admin ): ?>
					<div class="card-header">Users List <a href="<?php echo e(route('users.create')); ?>" class="pull-right" >Create New</a></div>
					<div class="card-body">
						<table class="table table-resposive">
							<thead>
								<tr>
									<th>Name</th>
									<th>Email</th>
									<th>Action	</th>
								</tr>
							</thead>
							<tbody>
								<?php if( $data['users']	 ): ?>
									<?php $__currentLoopData = $data['users']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if( ! $user->is_admin ): ?>
										<tr>
											<td><?php echo e($user->name); ?></td>
											<td><?php echo e($user->email); ?></td>
											<td>
											<div class="text-right">  
                                                    <a href="<?php echo e(route('users.edit', ['id' => $user->id ] )); ?>" class="btn btn-w-m btn-info btn_edit"><i class="fa fa-paste"></i> EDIT</a>
                                                    <form role="form" method="POST" action="<?php echo e(route('users.destroy', ['id' => $user->id ])); ?>" style="display:inline;">                                
                                                        <?php echo csrf_field(); ?>
                                                        <input type="hidden" name="_method" value="DELETE" />
                                                        <button type="submit" class="btn btn-w-m btn-danger btn_delete"  title="Delete"><i class="fa fa-close"></i> DELETE</button>                                 
                                                    </form>                                                                        
                                                </div>
											</td>
										</tr>
										
										<?php endif; ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php else: ?>
									
									<div>No User Found</div>
									
								<?php endif; ?>
							</tbody>
						</table>
					</div>
				<?php else: ?> 
					<div class="card-header">Dashboard</div>
					<div class="card-body">
						<?php if(session('status')): ?>
							<div class="alert alert-success" role="alert">
								<?php echo e(session('status')); ?>

							</div>
						<?php endif; ?>

						You are logged in!
					</div>
					
				<?php endif; ?>
				
				
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazam\resources\views/users/index.blade.php ENDPATH**/ ?>