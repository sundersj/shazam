<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Auth;
use Exception;
use Hash;
use Storage;
use App\User;


class UserController extends Controller
{
	
	/**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    
	}
	
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
		$data['users'] = User::where('is_admin', '!=', 1 )->get();
		
		return view('users.index')->with('data', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
		//
		if ( ! Auth::user()->is_admin ) {
			return back();
		}
		
		return view('users.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
		if ( ! Auth::user()->is_admin ) {
			return back();
		}
		
		$request->validate([
            'name'    		=>  'required',
            'email'         =>  'required|unique:users',
			'password'		=>	'required|confirmed|min:6'
        ]);
		
		$user = new User;
		$user->name = $request->name;
		$user->email = $request->email;
		$user->password = Hash::make( $request->password );
		$user->save();
		
		return redirect()->route('users.index');
		
		
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
		if ( ! Auth::user()->is_admin ) {
			return back();
		}
		
		return redirect()->route('users.index');
		
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      if ( ! Auth::user()->is_admin ) {
			return back();
		}
	  
		$user = User::find( $id );
		if( $user ) {
			return view('users.edit')->with(['user' => $user ]);
		} else {
			return back();
		}
		
	
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        if ( ! Auth::user()->is_admin ) {
			return back();
		}
		
		$request->validate([
            'name'    		=>  'required',
            'email'         =>  'required|unique:users',
        ]);
		
		
		$user = User::find( $id );
		
		$user->name = $request->name;
		$user->email = $request->email;
		$user->save();
		
		return redirect()->route('users.index');
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
		if ( ! Auth::user()->is_admin ) {
			return back();
		}
		
		$user = User::find( $id );
		
		if( ! $user ) {
			return back();
		}
		
		$user->delete();
		
		return redirect()->route('users.index');
	
    }
}
