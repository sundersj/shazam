<?php

use Illuminate\Database\Seeder;

use App\User;
use Illuminate\Support\Facades\Hash;


class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
		
        $admin = new User;
        $admin->name         =  'admin';
        $admin->email        =  'admin@gmail.com';
        $admin->password     =  Hash::make('123456');
        $admin->is_admin	 =  1;
        $admin->save();         
		
		
    }
}
