@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
				@if( auth::user()->is_admin )
					<div class="card-header">Users List <a href="{{ route('users.create') }}" class="pull-right" >Create New</a></div>
					<div class="card-body">
						<table class="table table-resposive">
							<thead>
								<tr>
									<th>Name</th>
									<th>Email</th>
									<th>Action	</th>
								</tr>
							</thead>
							<tbody>
								@if( $data['users']	 )
									@foreach( $data['users'] as $user )
										@if( ! $user->is_admin )
										<tr>
											<td>{{ $user->name }}</td>
											<td>{{ $user->email }}</td>
											<td>
											<div class="text-right">  
                                                    <a href="{{ route('users.edit', ['id' => $user->id ] ) }}" class="btn btn-w-m btn-info btn_edit"><i class="fa fa-paste"></i> EDIT</a>
                                                    <form role="form" method="POST" action="{{ route('users.destroy', ['id' => $user->id ])}}" style="display:inline;">                                
                                                        @csrf
                                                        <input type="hidden" name="_method" value="DELETE" />
                                                        <button type="submit" class="btn btn-w-m btn-danger btn_delete"  title="Delete"><i class="fa fa-close"></i> DELETE</button>                                 
                                                    </form>                                                                        
                                                </div>
											</td>
										</tr>
										
										@endif
									@endforeach
								@else
									
									<div>No User Found</div>
									
								@endif
							</tbody>
						</table>
					</div>
				@else 
					<div class="card-header">Dashboard</div>
					<div class="card-body">
						@if (session('status'))
							<div class="alert alert-success" role="alert">
								{{ session('status') }}
							</div>
						@endif

						You are logged in!
					</div>
					
				@endif
				
				
            </div>
        </div>
    </div>
</div>
@endsection